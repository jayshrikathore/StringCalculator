package NumberBiggerThan1000;

import org.junit.Assert;
import org.junit.Test;

import com.jayshri.stringcalculator.StringCalculator;

public class NumberBiggerTest {
	
	@Test
	public final void whenOneOrMoreNumbersAreGreaterThan1000IsUsedThenItIsNotIncludedInSum() {
	    Assert.assertEquals(3+1000+6, StringCalculator.add("3,1000,1001,6,1234"));
	}

}
