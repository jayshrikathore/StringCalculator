package UnknowAmountNumber;

import org.junit.Assert;
import org.junit.Test;

import com.jayshri.stringcalculator.StringCalculator;

public class UnknownNumberTest {
	@Test
    public final void whenAnyNumberOfNumbersIsUsedThenReturnValuesAreTheirSums() {
        Assert.assertEquals(3+6+15+18+46+33, StringCalculator.add("3,6,15,18,46,33"));
    }
}
