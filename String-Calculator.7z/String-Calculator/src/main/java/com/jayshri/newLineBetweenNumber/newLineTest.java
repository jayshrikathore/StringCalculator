package com.jayshri.newLineBetweenNumber;

import org.junit.Assert;
import org.junit.Test;

import com.jayshri.stringcalculator.StringCalculator;

public class newLineTest {
	
	@Test
	public final void whenNewLineIsUsedBetweenNumbersThenReturnValuesAreTheirSums() {
	    Assert.assertEquals(3+6+15, StringCalculator.add("3,6n15"));
	}

}
