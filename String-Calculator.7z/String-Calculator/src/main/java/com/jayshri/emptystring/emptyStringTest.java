package com.jayshri.emptystring;

import org.junit.Assert;
//import org.junit.Assert;
import org.junit.Test;
 
public class emptyStringTest {
    
	@Test
    public final void whenEmptyStringIsUsedThenReturnValueIs0() {
        Assert.assertEquals(0, emptystring.emptystringinput(""));
    }
}
