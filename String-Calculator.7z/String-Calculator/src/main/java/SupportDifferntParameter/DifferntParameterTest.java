package SupportDifferntParameter;

import org.junit.Assert;
import org.junit.Test;

import com.jayshri.stringcalculator.StringCalculator;

public class DifferntParameterTest {
	
	@Test
	public final void whenDelimiterIsSpecifiedThenItIsUsedToSeparateNumbers() {
	    Assert.assertEquals(3+6+15, StringCalculator.add("//;n3;6;15"));
	}

}
