package NegativeNumber;

import org.junit.Assert;
import org.junit.Test;

import com.jayshri.stringcalculator.StringCalculator;

public class negativeNumberTest {

	@Test(expected = RuntimeException.class)
	public final void whenNegativeNumberIsUsedThenRuntimeExceptionIsThrown() {
	    StringCalculator.add("3,-6,15,18,46,33");
	}
	@Test
	public final void whenNegativeNumbersAreUsedThenRuntimeExceptionIsThrown() {
	    RuntimeException exception = null;
	    try {
	        StringCalculator.add("3,-6,15,-18,46,33");
	    } catch (RuntimeException e) {
	        exception = e;
	    }
	    Assert.assertNotNull(exception);
	    Assert.assertEquals("Negatives not allowed: [-6, -18]", exception.getMessage());
	}
}
